//===------------------------ utility.cpp ---------------------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is dual licensed under the MIT and the University of Illinois Open
// Source Licenses. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#define _LIBCPP_BUILDING_UTILITY
#include "utility"

_LIBCPP_BEGIN_NAMESPACE_STD

const piecewise_construct_t piecewise_construct = {};

_LIBCPP_END_NAMESPACE_STD
