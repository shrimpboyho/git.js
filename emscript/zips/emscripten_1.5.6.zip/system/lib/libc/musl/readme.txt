These sources were downloaded from the musl-0.9.10 release on April 14, 2003.
