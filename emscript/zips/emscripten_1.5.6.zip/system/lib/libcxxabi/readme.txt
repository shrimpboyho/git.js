These files are from libcxxabi, svn revision 175275, Feb 15, 2013.
