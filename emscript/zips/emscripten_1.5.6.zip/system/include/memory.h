
#ifndef _MEMORY_H
#define _MEMORY_H

#include <sys/features.h>

#include <string.h>

#endif

