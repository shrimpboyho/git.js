The contents of this directory are from FreeBSD or OpenBSD (see details in each file).

