
// Basically do nothing, just use existing symbols

#include "SDL/SDL_opengl.h"
#define glewInit() {}

