stddef.h, stdarg.h - from Clang (svn pre-3.0)
Everything else - from Newlib (1.19)

