These files are from libc++, svn revision 187959, 2013-08-08.
