
#ifndef _SYS_POLL_H
#define _SYS_POLL_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

