work-in-progress demo with bullet and webgl (glge)

run ./server.sh (chrome does not like XHR on file://), then run one of

  google-chrome --enable-webgl 127.0.0.1:8991/demo.html
  firefox 127.0.0.1:8991/demo.html

(for firefox, requires beta7, preferably minefield/nightly builds).

