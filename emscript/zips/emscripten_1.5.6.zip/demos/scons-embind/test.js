var thelibrary = require('./build/thelibrary.js');
thelibrary.Module.print_some_stuff(1, 2, 'hello world');
