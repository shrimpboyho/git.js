#!/bin/bash
./test &> test.txt
./test2 &> test2.txt
./test3 &> test3.txt
./test_debug &> test_debug.txt
./test_dead &> test_dead.txt
./test4 &> test4.txt
./test5 &> test5.txt
./test6 &> test6.txt
./test_inf &> test_inf.txt
./test_fuzz1 &> test_fuzz1.txt
./test_fuzz2 &> test_fuzz2.txt
./test_fuzz3 &> test_fuzz3.txt
./test_fuzz4 &> test_fuzz4.txt
./test_fuzz5 &> test_fuzz5.txt
./test_fuzz6 &> test_fuzz6.txt

